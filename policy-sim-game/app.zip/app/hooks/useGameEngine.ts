import { useState, useCallback, useMemo, useEffect } from 'react';
import { Respondent, ElectionCycle, Policy, TurnHistory, GamePhase, TurnLedger, CompletedRun, CycleLedger } from '../utils/types';
import { loadPopulation, getONSBaselineLS } from '../utils/dataLoader';
import { WelfareMetrics } from '../utils/WelfareMetrics';
import { PolicyEngine } from '../utils/PolicyEngine';
import { MAOEngine } from '../utils/MAOEngine';
import { availablePolicies } from '../data/policies';
import { FRAMEWORK_RULES } from "../utils/frameworkRules";
import { MetricsEngine } from '../utils/MetricsEngine';
import { useSaveGame } from './useSaveGame';
import { track, setContext, startLevelAttempt, startTimer, stopTimer } from '../client/telemetry';

const TURNS_PER_CYCLE = 5;

const calculateAverage = (pop: Respondent[]): number => {
  return pop.length > 0 ? pop.reduce((sum, r) => sum + r.currentLS, 0) / pop.length : 0;
};

// Helper function to append the current metrics of all citizens into their ledgers
const recordTurnState = (pop: Respondent[], cycle: ElectionCycle, turn: number, policyId: string | null, policyName: string | null): Respondent[] => {
  const allLS = pop.map(p => p.currentLS);
  const multipliers = WelfareMetrics.getPopulationCurveMultipliers(allLS);

  return pop.map(p => {
    const pu = WelfareMetrics.getCycleUtility(p, ElectionCycle.PersonalUtility, pop.length, allLS, multipliers);
    const su = WelfareMetrics.getCycleUtility(p, ElectionCycle.SocietalUtility, pop.length, allLS, multipliers);
    
    const record: TurnLedger = { turn, policyId, policyName, ls: p.currentLS, personalUtility: pu, societalUtility: su };
    
    const newLedger = [...p.historicalLedger];
    const cycleIndex = newLedger.findIndex(l => l.cycle === cycle);
    
    if (cycleIndex >= 0) {
      newLedger[cycleIndex] = { ...newLedger[cycleIndex], turns: [...newLedger[cycleIndex].turns, record] };
    } else {
      newLedger.push({ cycle, turns: [record] });
    }
    
    return { ...p, historicalLedger: newLedger };
  });
};

export function useGameEngine(setActiveTab?: (tab: any) => void) {
  const [population, setPopulation] = useState<Respondent[]>([]);
  const [initialPopulation, setInitialPopulation] = useState<Respondent[]>([]);
  const [baselinePopulation, setBaselinePopulation] = useState<Respondent[]>([]);
  const [selectedPolicy, setSelectedPolicy] = useState<Policy | null>(null);
  const [pulsePolicy, setPulsePolicy] = useState(false);
  const [yAxisMax, setYAxisMax] = useState(100);
  const [hasSeenUtilityIntervention, setHasSeenUtilityIntervention] = useState(false);
  
  // Game starts on Intro phase now
  const [gamePhase, setGamePhase] = useState<GamePhase>(GamePhase.Intro);
  const isAgendaUnlocked = gamePhase === GamePhase.Playing;
  
  const [currentTurn, setCurrentTurn] = useState(1);
  const [currentCycle, setCurrentCycle] = useState<ElectionCycle>(ElectionCycle.Benthamite);
  const [cycleAttempts, setCycleAttempts] = useState(1);
  const [isEnacting, setIsEnacting] = useState(false);
  const [lastTurnSummary, setLastTurnSummary] = useState<{ policyName: string; scoreBefore: number; scoreAfter: number; turn: number } | null>(null);
  const [pressConferenceModifier, setPressConferenceModifier] = useState(0);
  const [isParliamentDissolved, setIsParliamentDissolved] = useState(false);
  const [history, setHistory] = useState<TurnHistory[]>([]);
  const [cycleSchedule, setCycleSchedule] = useState<Policy[][]>([]);
  const [cycleMAO, setCycleMAO] = useState<number>(0);
  const [currentDeck, setCurrentDeck] = useState<Policy[]>([]);
  const [optimalPath, setOptimalPath] = useState<Policy[]>([]);
  
  const [completedRuns, setCompletedRuns] = useState<CompletedRun[]>([]);
  const [dpmConsulted, setDpmConsultedState] = useState<Record<string, boolean>>({});

  const setDpmConsulted = useCallback((id: string, value: boolean) => {
    setDpmConsultedState(prev => ({ ...prev, [id]: value }));
  }, []);

  const resetDpmConsulted = useCallback(() => {
    setDpmConsultedState({});
  }, []);

  const startCycle = useCallback((cycle: ElectionCycle) => {
    let freshPop: Respondent[] = loadPopulation().map(p => ({
      ...p,
      currentLS: getONSBaselineLS(p.id),
      historicalLedger: [] as CycleLedger[]
    }));
    
    freshPop = recordTurnState(freshPop, cycle, 1, null, 'Took Office');

    const schedule = MetricsEngine.generateCycleSchedule(cycle, availablePolicies, TURNS_PER_CYCLE);
    setCycleSchedule(schedule);

    const maoResult = MAOEngine.calculateMAO(freshPop, schedule, cycle, MetricsEngine.getMetricScore);
    setCycleMAO(maoResult.maxScore);
    setOptimalPath(maoResult.optimalPath);

    const levelId = ElectionCycle[cycle];
    startLevelAttempt(levelId); // fresh attempt_id + incrementing attempt_number, resets turn to 0
    setContext({ levelId, turn: 1 });
    // NOTE: turn_started / policy_options_presented / the turn timer for
    // turn 1 are deliberately NOT fired here. At this point the player
    // hasn't seen the briefing modal yet, let alone accepted it - starting
    // the clock now would count the entire time spent reading/skipping the
    // briefing as "time on turn 1". They're fired from
    // handleBriefingAcknowledged() instead, once the player actually begins
    // the term.
    setCurrentDeck(schedule[0]);
    setCurrentTurn(1);
    setCurrentCycle(cycle);
    setIsParliamentDissolved(false);
    setHistory([{ turn: 1, enactedPolicyId: null, enactedPolicyName: 'Took Office', lsAverage: calculateAverage(freshPop) }]);
    setSelectedPolicy(null);
    setYAxisMax(100);
    setLastTurnSummary(null);
    setPressConferenceModifier(0);
    resetDpmConsulted();
    
    setPopulation(freshPop);
    setInitialPopulation(freshPop);
    setBaselinePopulation(freshPop);
    
    setGamePhase(GamePhase.Briefing);
  }, [resetDpmConsulted]);

  const handleSaveLoad = useCallback((parsed: any) => {
    setPopulation(parsed.population);
    setInitialPopulation(parsed.initialPopulation);
    setBaselinePopulation(parsed.baselinePopulation || parsed.initialPopulation);
    setCurrentTurn(parsed.currentTurn);
    setCurrentCycle(parsed.currentCycle);
    setCycleAttempts(parsed.cycleAttempts);
    setHistory(parsed.history);
    setCycleSchedule(parsed.cycleSchedule);
    setCycleMAO(parsed.cycleMAO);
    setCurrentDeck(parsed.currentDeck);
    setOptimalPath(parsed.optimalPath);
    setIsParliamentDissolved(parsed.isParliamentDissolved || false);
    setGamePhase(parsed.gamePhase || GamePhase.Intro);
    setCompletedRuns(parsed.completedRuns || []);
    setHasSeenUtilityIntervention(parsed.hasSeenUtilityIntervention || false);
  }, []);

  const handleSaveError = useCallback(() => {
    setGamePhase(GamePhase.Intro); 
  }, []);

  const gameStateSnapshot = useMemo(() => ({
      population, initialPopulation, baselinePopulation,
      currentTurn, currentCycle, cycleAttempts, history,
      cycleSchedule, cycleMAO, currentDeck, optimalPath,
      isParliamentDissolved, gamePhase, completedRuns, hasSeenUtilityIntervention
  }), [population, initialPopulation, baselinePopulation, currentTurn, currentCycle, cycleAttempts, history, cycleSchedule, cycleMAO, currentDeck, optimalPath, isParliamentDissolved, gamePhase, completedRuns, hasSeenUtilityIntervention]);

  const { wipeSave } = useSaveGame(gameStateSnapshot, handleSaveLoad, handleSaveError);

  const previewPopulation = useMemo(() => {
    if (!selectedPolicy) return population;
    return PolicyEngine.applyPolicy(population, selectedPolicy);
  }, [population, selectedPolicy]);

  const generateHistogramData = useCallback((targetPopulation: Respondent[]) => {
    return Array.from({ length: 11 }, (_, i) => {
      const peopleInBar = targetPopulation.filter(r => Math.round(r.currentLS) === i);
      return { name: i, count: peopleInBar.length };
    });
  }, []);

  const currentHistogramData = useMemo(() => generateHistogramData(population), [population, generateHistogramData]);
  const previewHistogramData = useMemo(() => generateHistogramData(previewPopulation), [previewPopulation, generateHistogramData]);

  useEffect(() => {
    const maxCurrent = Math.max(...currentHistogramData.map(d => d.count), 0);
    setYAxisMax(prev => {
      const targetMax = Math.max(100, Math.ceil(maxCurrent / 20) * 20);
      if (targetMax > prev) {
        return targetMax;
      }
      return prev;
    });
  }, [currentHistogramData]);

  const initialMetricScore = useMemo(() => MetricsEngine.getMetricScore(initialPopulation, currentCycle), [initialPopulation, currentCycle]);
  const turnMetricScore = useMemo(() => MetricsEngine.getMetricScore(population, currentCycle), [population, currentCycle]);
  const currentMetricScore = useMemo(() => MetricsEngine.getMetricScore(previewPopulation, currentCycle), [previewPopulation, currentCycle]);
  
  const turnApprovalRating = useMemo(() => {
    const base = WelfareMetrics.calculateApprovalRating(turnMetricScore, cycleMAO, FRAMEWORK_RULES[currentCycle].winThresholdScalar);
    return Math.max(0, Math.min(100, base + pressConferenceModifier));
  }, [turnMetricScore, cycleMAO, currentCycle, pressConferenceModifier]);

  const applyPressConferenceDelta = useCallback((delta: number) => {
    setPressConferenceModifier(prev => prev + delta);
  }, []);

  const handleNavigateToPolicy = useCallback(() => {
    if (setActiveTab) setActiveTab('legislative');
    setPulsePolicy(true);
    setTimeout(() => setPulsePolicy(false), 1500);
  }, [setActiveTab]);

  const handleApplyPolicy = () => {
    if (!selectedPolicy || isEnacting) return;

    // Stop the turn timer right now, at the actual moment "Enact" is
    // clicked - this is what time_on_turn_ms is supposed to measure (how
    // long the player spent deciding since the turn's options were
    // presented). The old code re-started this same timer here and only
    // stopped it 800ms later inside the setTimeout below, so it was only
    // ever measuring the fixed "Enacting Legislation..." animation delay
    // (hence every turn reporting ~800ms) instead of real decision time.
    const timeOnTurnMs = stopTimer('turn_active');

    // Compute everything synchronously now too, and fire policy_selected /
    // turn_completed immediately - not 800ms from now once the animation
    // finishes - so their timestamps reflect the actual click rather than
    // lagging behind it.
    const enactedTurn = currentTurn;
    const enactedPolicy = selectedPolicy;
    const levelId = ElectionCycle[currentCycle];
    const nextPop = recordTurnState(previewPopulation, currentCycle, enactedTurn + 1, enactedPolicy.id, enactedPolicy.policyName);
    const scoreBefore = MetricsEngine.getMetricScore(population, currentCycle);
    const scoreAfter = MetricsEngine.getMetricScore(nextPop, currentCycle);
    const populationBefore = calculateAverage(population);
    const populationAfter = calculateAverage(nextPop);

    track("policy_selected", {
      turn: enactedTurn,
      level_id: levelId,
      policy_id: enactedPolicy.id,
      options_available: currentDeck.map(p => p.id),
      score_before: scoreBefore,
      score_after: scoreAfter,
      // this game doesn't have a literal "population count" metric that
      // changes turn to turn - using average life satisfaction here as the
      // closest per-turn population-wellbeing signal.
      population_before: populationBefore,
      population_after: populationAfter,
    });
    track("turn_completed", {
      turn: enactedTurn,
      level_id: levelId,
      score: scoreAfter,
      population: populationAfter,
      time_on_turn_ms: timeOnTurnMs,
    });

    setIsEnacting(true);

    setTimeout(() => {
      setLastTurnSummary({ policyName: enactedPolicy.policyName, scoreBefore, scoreAfter, turn: enactedTurn });
      setPopulation(nextPop);

      setHistory(prev => [...prev, {
        turn: enactedTurn + 1,
        enactedPolicyId: enactedPolicy.id,
        enactedPolicyName: enactedPolicy.policyName,
        lsAverage: calculateAverage(previewPopulation)
      }]);

      const updatedSchedule = cycleSchedule.map((deck, idx) =>
        idx >= enactedTurn ? deck.filter(p => p.id !== enactedPolicy.id) : deck
      );
      setCycleSchedule(updatedSchedule);

      if (enactedTurn < TURNS_PER_CYCLE) {
        const nextTurn = enactedTurn + 1;
        setCurrentDeck(updatedSchedule[enactedTurn]);
        setCurrentTurn(nextTurn);
        setContext({ turn: nextTurn });
        track("turn_started", { turn: nextTurn, level_id: levelId, score: scoreAfter, population: populationAfter });
        track("policy_options_presented", { turn: nextTurn, level_id: levelId, options: updatedSchedule[enactedTurn].map(p => p.id) });
        // Timer for the *new* turn correctly starts now, once its options
        // are actually on screen - this part was already right.
        startTimer('turn_active');
      } else {
        setIsParliamentDissolved(true);
      }

      setSelectedPolicy(null);
      setIsEnacting(false);
    }, 800);
  };

  // Called when the player accepts the mandate in BriefingModal (or uses the
  // retry "Skip Briefing" button) - this is the true start of turn 1, so
  // turn_started/policy_options_presented/the turn timer belong here rather
  // than back in startCycle (see note there).
  const handleBriefingAcknowledged = useCallback(() => {
    const levelId = ElectionCycle[currentCycle];
    setContext({ levelId, turn: 1 });
    track("turn_started", {
      turn: 1,
      level_id: levelId,
      score: MetricsEngine.getMetricScore(population, currentCycle),
      population: calculateAverage(population),
    });
    track("policy_options_presented", {
      turn: 1,
      level_id: levelId,
      options: currentDeck.map(p => p.id),
    });
    startTimer('turn_active');
    setGamePhase(GamePhase.Playing);
  }, [currentCycle, population, currentDeck]);

  const handleFaceElectorate = useCallback(() => {
    setLastTurnSummary(null);
    setGamePhase(GamePhase.Election);
  }, []);

  const handleResetCycle = useCallback(() => {
    track("level_attempt_ended", {
      level_id: ElectionCycle[currentCycle],
      attempt_number: cycleAttempts,
      outcome: "abandoned",
      turns_taken: currentTurn,
    });
    wipeSave();
    startCycle(currentCycle);
    setCycleAttempts(prev => prev + 1);
  }, [currentCycle, currentTurn, cycleAttempts, wipeSave, startCycle]);

  const jumpToCycle = (cycle: ElectionCycle) => {
    wipeSave();
    startCycle(cycle);
    setCycleAttempts(1);
  };

  // Starts a term cleanly without wiping the save, allowing progression
  const startLevel = useCallback((cycle: ElectionCycle) => {
    // Intercept Cycle 3 if they haven't seen the intervention
    if (cycle === ElectionCycle.SocietalUtility && !hasSeenUtilityIntervention) {
      setCurrentCycle(cycle); // Lock in the cycle they are attempting to start
      setGamePhase(GamePhase.UtilityIntervention);
      return;
    }

    startCycle(cycle);
    setCycleAttempts(1);
  }, [startCycle, hasSeenUtilityIntervention]);

  const handleCompleteTerm = useCallback(() => {
    const rule = FRAMEWORK_RULES[currentCycle];
    const targetScore = cycleMAO * rule.winThresholdScalar;

    track("level_completed", {
      level_id: ElectionCycle[currentCycle],
      outcome: turnMetricScore >= targetScore ? "win" : "lose",
      turns_taken: currentTurn,
      final_score: turnMetricScore,
    });

    const run: CompletedRun = {
      cycle: currentCycle,
      finalPopulation: [...population],
      finalScore: turnMetricScore,
      targetScore,
      approvalRating: turnApprovalRating,
      enactedLegislation: [...history]
    };

    setCompletedRuns(prev => {
      const clone = [...prev];
      const idx = clone.findIndex(r => r.cycle === currentCycle);
      if (idx >= 0) {
        clone[idx] = run;
      } else {
        clone.push(run);
      }
      return clone;
    });

    setGamePhase(GamePhase.LevelSelect);
  }, [currentCycle, population, turnMetricScore, cycleMAO, turnApprovalRating, history, currentTurn]);

  const currentChartData = useMemo(() => {
    if (population.length === 0) return [];
    const allLS = population.map(p => p.currentLS);
    const multipliers = currentCycle === ElectionCycle.SocietalUtility ? WelfareMetrics.getPopulationCurveMultipliers(allLS) : null;
    
    return population.map(r => {
      const yVal = WelfareMetrics.getCycleUtility(r, currentCycle, population.length, allLS, multipliers);
      return { id: r.id, x: r.currentLS, y: yVal };
    });
  }, [population, currentCycle]);

  const previewChartData = useMemo(() => {
    if (previewPopulation.length === 0) return [];
    const allLS = previewPopulation.map(p => p.currentLS);
    const multipliers = currentCycle === ElectionCycle.SocietalUtility ? WelfareMetrics.getPopulationCurveMultipliers(allLS) : null;
    
    return previewPopulation.map(r => {
      const yVal = WelfareMetrics.getCycleUtility(r, currentCycle, previewPopulation.length, allLS, multipliers);
      return { id: r.id, x: r.currentLS, y: yVal };
    });
  }, [previewPopulation, currentCycle]);

  return {
    population, initialPopulation, baselinePopulation, previewPopulation,
    currentTurn, currentCycle, cycleAttempts,
    selectedPolicy, setSelectedPolicy, pulsePolicy, isEnacting,
    isParliamentDissolved, handleFaceElectorate,
    history, currentDeck, cycleMAO, optimalPath,
    turnMetricScore, initialMetricScore, currentMetricScore, turnApprovalRating,
    currentChartData, previewChartData, currentHistogramData, previewHistogramData,
    handleApplyPolicy, handleResetCycle, jumpToCycle, handleCompleteTerm, setCurrentTurn, handleNavigateToPolicy,
    handleBriefingAcknowledged,
    startLevel,
    gamePhase, setGamePhase, isAgendaUnlocked, yAxisMax,
    TURNS_PER_CYCLE,
    completedRuns,
    dpmConsulted, setDpmConsulted, resetDpmConsulted,
    wipeSave,
    lastTurnSummary, clearLastTurnSummary: () => setLastTurnSummary(null),
    applyPressConferenceDelta,
    setHasSeenUtilityIntervention, startCycle
  };
}